$.validator.addMethod("datenotgreaterthancurrent",
            function (value, element, parameters) {
                if(value === null || value === undefined || value === '') {
                    console.log(value);
                    return true;
                }
                else {
                    var dateNow = new Date(); 
                    var date =  (dateNow.getMonth()+1)+'/'+dateNow.getDate()+'/'+dateNow.getFullYear();
                    var cleanDateToday = new Date(date);

                    return new Date(value).getTime() <= cleanDateToday.getTime();
                }
                
            });

        $.validator.unobtrusive.adapters.add("datenotgreaterthancurrent", [], function (options) {
            options.rules.datenotgreaterthancurrent = {};
            options.messages["datenotgreaterthancurrent"] = 'Date should not be greater than today';
        });