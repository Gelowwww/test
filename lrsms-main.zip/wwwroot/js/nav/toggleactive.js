$(document).ready(function () {
    var url = window.location.pathname;
    var substr = url.split('/');
    var urlaspx = substr[1];
    // var urlaspx = substr[substr.length - 1];
    
    $('.navbar').find('.active').removeClass('active');

    if(urlaspx != '') {
        $('.navbar li').find('a').each(function () {
            
            if (this.href.indexOf(urlaspx) == 23) {
                console.log(urlaspx);
                $(this).parents('li').addClass('active');
            }
        });
    }

});