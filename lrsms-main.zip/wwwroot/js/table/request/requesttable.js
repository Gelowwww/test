function deleteData(url){
    $.ajax({
        type: 'DELETE',
        url: url,
        success: () => location.reload()
    })
};

$(document).ready(function () {
    $('#RequestTable tfoot th').each( function () {
        var title = $(this).text();

        if( $(this).hasClass('input-filter')) {
            $(this).html('<input type="text" class = "form-control" placeholder="Search ' + $.trim(title) + '" />');

        } else if( $(this).hasClass('date-filter')) {
            $(this).html('<input type="text" autocomplete="off" name="' + $.trim(title).replace(/ /g, '') + '"  placeholder="Search ' + $.trim(title) + '" class="form-control daterange"/>');
        }
    } );

    $.ajax({
        url:'/data/getrequestdata',
        type: 'GET',
        datatype: 'json',
        success: (data) => {
           var table= $('#RequestTable').DataTable( {
                    dom: 'Blfrtip',
                    buttons: [
                        // {extend: 'copy', text: '<i class="fa fa-files-o" aria-hidden="true"></i>', titleAttr: 'copy', className: 'btn btn-dark', exportOptions: { columns: [0, 1, 2, 3] }, title: 'Request List'},
                        {extend: 'excel', text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i>', titleAttr: 'excel', className: 'btn btn-success', exportOptions: { columns: [0, 1, 2, 3] }, title: 'Request List'},
                        {extend: 'pdf', text: '<i class="fa fa-file-pdf-o" aria-hidden="true"></i>', titleAttr: 'pdf', className: 'btn btn-danger', exportOptions: { columns: [0, 1, 2, 3] }, title: 'Request List',
                        customize: function (doc) {
                            doc.content[1].table.widths = 
                                Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                        }},
                        // {extend: 'print', text: '<i class="fa fa-print" aria-hidden="true"></i>', titleAttr: 'print', className: 'btn btn-secondary', exportOptions: { columns: [0, 1, 2, 3] }, title: 'Request List'},
                        // 'colvis'
                    ],
                    ajax: {url: '/data/getrequestdata', dataSrc: ''},
                    columns: [
                        {data: 'Id', title: 'Id'},
                        {data: 'RequestName', title: 'Request Name'},
                        {data: 'CreatedAt', title: 'Created At'},
                        {data: 'CreatedBy', title: 'Created By'},
                        {data: null, title: 'Actions', sortable: false, searchable: false, render: function( data, type, row) {
                            var viewUrl = '/Request/ViewRequestDetails?id=' + data.Id;
                            var editUrl = '/Request/Edit?id=' + data.Id;
                            var deleteUrl = '/Request/Delete?id=' + data.Id;

                            return `
                            <div class="btn-group" role="group">
                                <a type="button" title="view" class="btn btn-primary" href="${viewUrl}"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                <a type="button" title="edit" class="btn btn-primary" href="${editUrl}"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                <button type="button" title="delete" class="btn btn-danger" data-toggle="modal" data-target="#delete${data.Id}"><i class="fa fa-trash" aria-hidden="true"></i></button>
                            </div>

                            <div class="modal fade" id="delete${data.Id}" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle">Delete ${data.RequestName}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to delete <strong>${data.RequestName}<strong>?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" id="btn${data.Id}" class="btn btn-danger" onClick="deleteData('${deleteUrl}')">Delete</button>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            `
                        }}
                    ]
            } );
               
            $('.daterange').daterangepicker({
                ranges: {
                    "Today": [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '7 last days': [moment().subtract(6, 'days'), moment()],
                    '30 last days': [moment().subtract(29, 'days'), moment()],
                    'This month': [moment().startOf('month'), moment().endOf('month')],
                    'Last month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                autoUpdateInput: false,
                opens: "left",
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                }
            });

            //get column index for date range
            var visiblecolumnIndex;
            var dataColumnIndex; //current data column to work with

            $("#RequestTable_wrapper tfoot").on("mousedown", "th", function(event) {
                visiblecolumnIndex = $(this).parent().children().index($(this));
                dataColumnIndex = $("tr:first-child").children(':eq(' + visiblecolumnIndex + ')').attr('data-column-index');
                console.log('col: ' + visiblecolumnIndex);
            });

            var startDate;
            var endDate;

            var DateFilterFunction = (function(settings, data, iDataIndex) {

                var filterstart = startDate;
                var filterend = endDate;
                var iStartDateCol = visiblecolumnIndex;
                var iEndDateCol = visiblecolumnIndex;

                console.log('istart: ' + iStartDateCol);
                console.log('iend: ' + iEndDateCol);

                var tabledatestart = data[iStartDateCol] !== "" ? moment(data[iStartDateCol], "YYYY-MM-DD") : data[iStartDateCol];
                var tabledateend = data[iEndDateCol] !== "" ? moment(data[iEndDateCol], "YYYY-MM-DD") : data[iEndDateCol];

                console.log('moment start: '+ data[iStartDateCol]);
                console.log('moment end: '+ data[iEndDateCol]);

                console.log('start: ' + tabledatestart);
                console.log('end: ' + tabledateend);

                if (filterstart === "" && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isAfter(tabledatestart)) && filterstart === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && (moment(filterend, "YYYY-MM-DD").isSame(tabledateend) || moment(filterend, "YYYY-MM-DD").isAfter(tabledateend))) {
                    return true;
                }

                return false;


            });

            $(".daterange", this).on('apply.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });

            $(".daterange", this).on('cancel.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val('');
                startDate = '';
                endDate = '';
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });
    
            

            // Apply the search
            $.each($('.input-filter', table.table().footer()), function () {
                var column = table.column($(this).index());
                
                $('input', this).on('keyup change', function () {
                    if (column.search() !== this.value) {
                        column
                            .search(this.value)
                            .draw();
                    }
                });
            });
        }
    });
});