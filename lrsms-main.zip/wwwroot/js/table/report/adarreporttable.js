$(document).ready(function () {
    $('.chosen-select').chosen();
    loadAuthDropdown();
    loadAreaDropdown();
    loadBranchDropdown();
    loadFacilityhDropdown();
    loadRegionDropdown();

    $('#AdarReportTable tfoot th').each( function () {
        var title = $(this).text();

        if( $(this).hasClass('input-filter')) {
            $(this).html('<input type="text" class = "form-control" placeholder="Search ' + $.trim(title) + '" />');

        } else if( $(this).hasClass('date-filter')) {
            $(this).html('<input type="text" autocomplete="off" name="' + $.trim(title).replace(/ /g, '') + '"  placeholder="Search ' + $.trim(title) + '" class="form-control daterange"/>');
        }
    } );

    $.ajax({
        url:'/data/GetAdarReportData',
        type: 'GET',
        datatype: 'json',
        success: (data) => {
           var table= $('#AdarReportTable').DataTable( {
                    dom: 'Blfrtip',
                    buttons: [
                        // {extend: 'copy', text: '<i class="fa fa-files-o" aria-hidden="true"></i>', titleAttr: 'copy', className: 'btn btn-dark', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List'},
                        {extend: 'excel', text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i>', titleAttr: 'excel', className: 'btn btn-success', title: 'ADAR Report List'},
                        {extend: 'pdf', text: '<i class="fa fa-file-pdf-o" aria-hidden="true"></i>', titleAttr: 'pdf', className: 'btn btn-danger', orientation: 'landscape', pageSize: 'A0', title: 'ADAR Report List',
                        customize: function (doc) {
                            doc.content[1].table.widths = 
                                Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                        }},
                        // {extend: 'print', text: '<i class="fa fa-print" aria-hidden="true"></i>', titleAttr: 'print', className: 'btn btn-secondary', orientation: 'landscape', pageSize: 'A0', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List'},
                    ],
                    processing: true,
                    ajax: {url: '/data/GetAdarReportData', dataSrc: ''},
                    columns: [
                        {data: 'RefNo', title: 'Reference No'},
                        {data: 'LrId', title: 'LR ID'},
                        {data: 'ReportDate', title: 'Report Date'},
                        {data: 'DateReceived', title: 'Received Date'},
                        {data: 'HoReceivedDate', title: 'H.O Received Date'},
                        {data: 'ApprovingAuthorityName', title: 'Approving Authority'},
                        {data: 'BranchName', title: 'Branch'},
                        {data: 'AreaName', title: 'Area'},
                        {data: 'RegionName', title: 'Region'},
                        {data: 'Analyst', title: 'Analyst'},
                        {data: 'AccountName', title: 'Account Name'},
                        {data: 'RequestName', title: 'Request'},
                        {data: 'FacilityName', title: 'Facility'},
                        {data: 'CollateralCategory', title: 'Collateral Category'},
                        {data: 'Description', title: 'Description'},
                        {data: 'CurrencyName', title: 'Currency'},
                        {data: 'AmountFrom', title: 'Amount From'},
                        {data: 'AmountTo', title: 'Amount To'},
                        {data: 'SecurityCollateralName', title: 'Security Collateral'},
                        {data: 'Status', title: 'Status'},
                        {data: 'Remarks', title: 'Remarks'},
                        {data: 'StatusEffectiveDate', title: 'Status Effective Date'},
                        {data: 'DateExpiry', title: 'Date Expiry'},
                        {data: 'ExpiryPeriod', title: 'Expiry Period'},
                    ]
            } );
            
            $('.daterange').daterangepicker({
                ranges: {
                    "Today": [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '7 last days': [moment().subtract(6, 'days'), moment()],
                    '30 last days': [moment().subtract(29, 'days'), moment()],
                    'This month': [moment().startOf('month'), moment().endOf('month')],
                    'Last month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                autoUpdateInput: false,
                opens: "left",
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                }
            });

            //get column index for date range
            var visiblecolumnIndex;
            var dataColumnIndex; //current data column to work with

            $("#AdarReportTable_wrapper tfoot").on("mousedown", "th", function(event) {
                visiblecolumnIndex = $(this).parent().children().index($(this));
                dataColumnIndex = $("tr:first-child").children(':eq(' + visiblecolumnIndex + ')').attr('data-column-index');
                console.log('col: ' + visiblecolumnIndex);
            });

            var startDate;
            var endDate;

            var DateFilterFunction = (function(settings, data, iDataIndex) {

                var filterstart = startDate;
                var filterend = endDate;
                var iStartDateCol = visiblecolumnIndex;
                var iEndDateCol = visiblecolumnIndex;

                var tabledatestart = data[iStartDateCol] !== "" ? moment(data[iStartDateCol].split('T')[0], "YYYY-MM-DD") : data[iStartDateCol];
                var tabledateend = data[iEndDateCol] !== "" ? moment(data[iEndDateCol].split('T')[0], "YYYY-MM-DD") : data[iEndDateCol];

                if (filterstart === "" && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isAfter(tabledatestart)) && filterstart === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && (moment(filterend, "YYYY-MM-DD").isSame(tabledateend) || moment(filterend, "YYYY-MM-DD").isAfter(tabledateend))) {
                    return true;
                }

                return false;


            });

            $(".daterange", this).on('apply.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });

            $(".daterange", this).on('cancel.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val('');
                startDate = '';
                endDate = '';
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });
    
            

            // Apply the search
            $.each($('.input-filter', table.table().footer()), function () {
                var column = table.column($(this).index());
                
                $('input', this).on('keyup change', function () {
                    if (column.search() !== this.value) {
                        column
                            .search(this.value)
                            .draw();
                    }
                });
            }); 

            
          
            $('select').on('change', function () {
                table.draw();
            });
        }
    });
});

//appr auth
$.fn.dataTable.ext.search.push(
    function(settings, searchData, index, rowData, counter) {
        var selected = $('#ApprovingAuth').val().map((x) => {
            return x;
        });
        
        if(selected.length === 0) {
            return true;
        }
        
        if (selected.indexOf(searchData[3]) !== -1) {
            return true;
        }
        
        return false;
    }
)

$.fn.dataTable.ext.search.push(
    function(settings, searchData, index, rowData, counter) {
        var selected = $('#Region').val().map((x) => {
            return x;
        });
        
        if(selected.length === 0) {
            return true;
        }
        
        if (selected.indexOf(searchData[4]) !== -1) {
            return true;
        }
        
        return false;
    }
)

$.fn.dataTable.ext.search.push(
    function(settings, searchData, index, rowData, counter) {
        var selected = $('#Area').val().map((x) => {
            return x;
        });
        
        if(selected.length === 0) {
            return true;
        }
        
        if (selected.indexOf(searchData[5]) !== -1) {
            return true;
        }
        
        return false;
    }
)

$.fn.dataTable.ext.search.push(
    function(settings, searchData, index, rowData, counter) {
        var selected = $('#Branch').val().map((x) => {
            return x;
        });
        
        if(selected.length === 0) {
            return true;
        }
        
        if (selected.indexOf(searchData[6]) !== -1) {
            return true;
        }
        
        return false;
    }
)

$.fn.dataTable.ext.search.push(
    function(settings, searchData, index, rowData, counter) {
        var selected = $('#Cancelled').val().map((x) => {
            return x;
        });
        
        if(selected.length === 0) {
            return true;
        }
        
        if (selected.indexOf(searchData[9]) !== -1) {
            return true;
        }
        
        return false;
    }
)

let getAuths = $.ajax({
    url: '/data/getapprovingauthoritydata/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});

let getRegions = $.ajax({
    url: '/data/getregiondata/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});


let getAreas = $.ajax({
    url: '/data/getareadata/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});

let getBranches = $.ajax({
    url: '/data/getbranchdata/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});

let getFacilities = $.ajax({
    url: '/data/GetFacilityData/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});

function loadAuthDropdown() {
    $('#ApprovingAuth').empty();

    getAuths.responseJSON.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.ApprovingAuthorityName;
        opt.value = element.ApprovingAuthorityName;
        
        $('#ApprovingAuth').append(opt);
    });

    $('#ApprovingAuth').trigger('chosen:updated');
}

function loadRegionDropdown() {
    $('#Region').empty();

    getRegions.responseJSON.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.RegionName;
        opt.value = element.RegionName;
        
        $('#Region').append(opt);
    });

    $('#Region').trigger('chosen:updated');
}

function loadAreaDropdown() {
    $('#Area').empty();

    getAreas.responseJSON.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.AreaName;
        opt.value = element.AreaName;
        
        $('#Area').append(opt);
    });

    $('#Area').trigger('chosen:updated');
}

function loadBranchDropdown() {
    $('#Branch').empty();

    getBranches.responseJSON.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.BranchName;
        opt.value = element.BranchName;
        
        $('#Branch').append(opt);
    });

    $('#Branch').trigger('chosen:updated');
}

function loadFacilityhDropdown() {
    $('#Cancelled').empty();

    getFacilities.responseJSON.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.FacilityName;
        opt.value = element.FacilityName;
        
        $('#Cancelled').append(opt);
    });

    $('#Cancelled').trigger('chosen:updated');
}