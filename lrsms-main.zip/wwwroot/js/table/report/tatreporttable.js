$(document).ready(function () {
    $('#TatReportTable tfoot th').each( function () {
        var title = $(this).text();

        if( $(this).hasClass('input-filter')) {
            $(this).html('<input type="text" class = "form-control" placeholder="Search ' + $.trim(title) + '" />');

        } else if( $(this).hasClass('date-filter')) {
            $(this).html('<input type="text" autocomplete="off" name="' + $.trim(title).replace(/ /g, '') + '"  placeholder="Search ' + $.trim(title) + '" class="form-control daterange"/>');
        }
    } );

    $.ajax({
        url:'/data/GetTatReportData',
        type: 'GET',
        datatype: 'json',
        success: (data) => {
           var table= $('#TatReportTable').DataTable( {
                    dom: 'Blfrtip',
                    buttons: [
                        // {extend: 'copy', text: '<i class="fa fa-files-o" aria-hidden="true"></i>', titleAttr: 'copy', className: 'btn btn-dark', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List'},
                        {extend: 'excel', text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i>', titleAttr: 'excel', className: 'btn btn-success', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List'},
                        {extend: 'pdf', text: '<i class="fa fa-file-pdf-o" aria-hidden="true"></i>', titleAttr: 'pdf', className: 'btn btn-danger', orientation: 'landscape', pageSize: 'A0', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List',
                        customize: function (doc) {
                            doc.content[1].table.widths = 
                                Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                        }},
                        // {extend: 'print', text: '<i class="fa fa-print" aria-hidden="true"></i>', titleAttr: 'print', className: 'btn btn-secondary', orientation: 'landscape', pageSize: 'A0', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6] }, title: 'TAT Report List'},
                    ],
                    processing: true,
                    ajax: {url: '/data/GetTatReportData', dataSrc: ''},
                    columns: [
                        {data: 'Id', title: 'Id'},
                        {data: 'RefNo', title: 'Reference No'},
                        {data: 'EntityResponsible', title: 'Entity Responsible'},
                        {data: 'Position', title: 'Position'},
                        {data: 'Status', title: 'Status'},
                        {data: 'NextEntityResponsible', title: 'Next Entity Responsible'},
                        {data: 'StatusEffectiveDate', title: 'Status Effective Date'},
                        {data: 'TatCount', title: 'TAT Count'},
                        {data: 'CrmId', title: 'CRM Id'},
                    ]
            } );
            
            $('.daterange').daterangepicker({
                ranges: {
                    "Today": [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '7 last days': [moment().subtract(6, 'days'), moment()],
                    '30 last days': [moment().subtract(29, 'days'), moment()],
                    'This month': [moment().startOf('month'), moment().endOf('month')],
                    'Last month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                autoUpdateInput: false,
                opens: "left",
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                }
            });

            //get column index for date range
            var visiblecolumnIndex;
            var dataColumnIndex; //current data column to work with

            $("#TatReportTable_wrapper tfoot").on("mousedown", "th", function(event) {
                visiblecolumnIndex = $(this).parent().children().index($(this));
                dataColumnIndex = $("tr:first-child").children(':eq(' + visiblecolumnIndex + ')').attr('data-column-index');
                console.log('col: ' + visiblecolumnIndex);
            });

            var startDate;
            var endDate;

            var DateFilterFunction = (function(settings, data, iDataIndex) {

                var filterstart = startDate;
                var filterend = endDate;
                var iStartDateCol = visiblecolumnIndex;
                var iEndDateCol = visiblecolumnIndex;

                var tabledatestart = data[iStartDateCol] !== "" ? moment(data[iStartDateCol].split('T')[0], "YYYY-MM-DD") : data[iStartDateCol];
                var tabledateend = data[iEndDateCol] !== "" ? moment(data[iEndDateCol].split('T')[0], "YYYY-MM-DD") : data[iEndDateCol];

                if (filterstart === "" && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isAfter(tabledatestart)) && filterstart === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && (moment(filterend, "YYYY-MM-DD").isSame(tabledateend) || moment(filterend, "YYYY-MM-DD").isAfter(tabledateend))) {
                    return true;
                }

                return false;


            });

            $(".daterange", this).on('apply.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });

            $(".daterange", this).on('cancel.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val('');
                startDate = '';
                endDate = '';
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });
    
            

            // Apply the search
            $.each($('.input-filter', table.table().footer()), function () {
                var column = table.column($(this).index());
                
                $('input', this).on('keyup change', function () {
                    if (column.search() !== this.value) {
                        column
                            .search(this.value)
                            .draw();
                    }
                });
            }); 
        }
    });
});