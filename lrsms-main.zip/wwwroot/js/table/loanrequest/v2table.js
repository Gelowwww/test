function deleteData(url){
    $.ajax({
        type: 'DELETE',
        url: url,
        success: () => { 
            location.reload();
            return false;
         },
        error: (err) => { 
            alert('You cannot delete this Loan Request');
        }
    })
};

$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#MinFrom').val(), 10 );
        var max = parseInt( $('#MaxFrom').val(), 10 );
        var from = parseFloat( data[12] ) || 0;
 
        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && from <= max ) ||
             ( min <= from   && isNaN( max ) ) ||
             ( min <= from   && from <= max ) )
        {
            return true;
        }
        return false;
    }
);

$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#MinTo').val(), 10 );
        var max = parseInt( $('#MaxTo').val(), 10 );
        var from = parseFloat( data[13] ) || 0;
 
        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && from <= max ) ||
             ( min <= from   && isNaN( max ) ) ||
             ( min <= from   && from <= max ) )
        {
            return true;
        }
        return false;
    }
);

$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#MinAsset').val(), 10 );
        var max = parseInt( $('#MaxAsset').val(), 10 );
        var from = parseFloat( data[20] ) || 0;
 
        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && from <= max ) ||
             ( min <= from   && isNaN( max ) ) ||
             ( min <= from   && from <= max ) )
        {
            return true;
        }
        return false;
    }
);

$(document).ready(function () {
    $('#LoanRequestTable tfoot th').each( function () {
        var title = $(this).text();

        if( $(this).hasClass('input-filter')) {
            $(this).html('<input type="text" class = "form-control" placeholder="Search ' + $.trim(title) + '" />');

        } else if( $(this).hasClass('date-filter')) {
            $(this).html('<input type="text" autocomplete="off" name="' + $.trim(title).replace(/ /g, '') + '"  placeholder="Search ' + $.trim(title) + '" class="form-control daterange"/>');
        }
        
    } );

    $.ajax({
        url:'/data/getloanrequestdata',
        type: 'GET',
        datatype: 'json',
        success: (data) => {
           var table= $('#LoanRequestTable').DataTable( {
                    dom: 'Blfrtip',
                    buttons: [
                        // {extend: 'copy', text: '<i class="fa fa-files-o" aria-hidden="true"></i>', titleAttr: 'copy', className: 'btn btn-dark', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] }, title: 'LR List'},
                        // {extend: 'csv', className: 'btn btn-success', exportOptions: { columns: [0, 1, 2, 3] }},
                        {extend: 'excel', text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i>', titleAttr: 'excel', className: 'btn btn-success', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] }, title: 'LR List'},
                        {extend: 'pdf', text: '<i class="fa fa-file-pdf-o" aria-hidden="true"></i>', titleAttr: 'pdf',  orientation: 'landscape', pageSize: 'A0', className: 'btn btn-danger', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] }, title: 'LR List',
                        customize: function (doc) {
                            doc.content[1].table.widths = 
                                Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                        }},
                        // {extend: 'print', text: '<i class="fa fa-print" aria-hidden="true"></i>', titleAttr: 'print',  orientation: 'landscape', pageSize: 'A0', className: 'btn btn-secondary', exportOptions: { columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] }, title: 'LR List'},
                        // 'colvis'
                    ],
                    processing: true,
                    ajax: {url: '/data/getloanrequestdata', dataSrc: ''},
                    columns: [
                        {data: 'LrId', title: 'Id'},
                        {data: 'Status', title: 'Status'},
                        {data: 'StatusEffectiveDate', title: 'Status Effective Date'},
                        {data: 'RefNo', title: 'Reference No', render: function(data, type, row) {
                            if(type === 'display') {
                                data = '<a href="/LoanRequest/ViewCrmDetails?id=' + row.CrmId + '">' + data + '</a>';
                            }
                            return data;
                        }},
                        {data: 'DateReceived', title: 'Date Received'},
                        {data: 'OldNew', title: 'Old/New'},
                        {data: 'RegionName', title: 'Region Name'},
                        {data: 'AreaName', title: 'Area Name'},
                        {data: 'BranchName', title: 'Branch Name'},
                        {data: 'AccountName', title: 'Account Name'},
                        {data: 'RequestName', title: 'Request'},
                        {data: 'FacilityName', title: 'Facility Name'},
                        {data: 'Description', title: 'Description'},
                        {data: 'CurrencyName', title: 'Currency Name'},
                        {data: 'AmountFrom', title: 'Amount From'},
                        {data: 'AmountTo', title: 'Amount To'},
                        {data: 'SecurityCollateralName', title: 'Security Collateral Name'},
                        {data: 'ApprovingAuthorityName', title: 'Approving Authority Name'},
                        {data: 'DateExpiry', title: 'Date Expiry'},
                        {data: 'ExpiryPeriod', title: 'Expiry Period'},
                        {data: 'ReportDate', title: 'Report Date'},
                        {data: 'DateSentToBranches', title: 'Date Sent To Branches'},
                        {data: 'AssetSize', title: 'AssetSize'},
                        {data: 'CollateralSharingWithCbg', title: 'Collateral Sharing With CBG'},
                        {data: 'CollateralSharingWithCbgDetails', title: 'Collateral Sharing With CBG Details'},
                        {data: 'CreatedAt', title: 'Created At'},
                        {data: 'CreatedBy', title: 'Created By'},
                        {data: null, title: 'Actions', sortable: false, searchable: false, render: function( data, type, row) {
                            var viewCrmUrl = '/LoanRequest/ViewCrmDetails?id=' + data.CrmId;
                            var viewLrUrl = '/LoanRequest/ViewLoanRequestDetails?id=' + data.LrId;
                            var editUrl = '@Url.Action("Edit", "LoanRequest")?id=' + data.LrId;
                            var editCrmUrl = '/LoanRequest/EditCrm?id=' + data.CrmId;
                            var editLrUrl = '/LoanRequest/EditLr?id=' + data.LrId;
                            var deleteUrl = '/LoanRequest/Delete?id=' + data.LrId;

                            return `
                            <div class="btn-group" role="group">
                                <a type="button" title="view" class="btn btn-primary" href="${viewCrmUrl}"><i class="fa fa-eye" aria-hidden="true"></i> CRM</a>
                                <a type="button" title="edit" class="btn btn-primary" href="${editCrmUrl}"><i class="fa fa-pencil" aria-hidden="true"></i> CRM</a>
                                <a type="button" title="view" class="btn btn-primary" href="${viewLrUrl}"><i class="fa fa-eye" aria-hidden="true"></i> LR</a>
                                <a type="button" title="edit" class="btn btn-primary" href="${editLrUrl}"><i class="fa fa-pencil" aria-hidden="true"> LR</i></a>
                                <button type="button" title="delete" class="btn btn-danger" data-toggle="modal" data-target="#delete${data.LrId}"><i class="fa fa-trash" aria-hidden="true"></i></button>
                            </div>

                            <div class="modal fade" id="delete${data.LrId}" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle">Delete ${data.RefNo}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        Do you want to delete <strong>${data.RefNo}<strong>?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" id="btn${data.LrId}" class="btn btn-danger" onClick="deleteData('${deleteUrl}')">Delete</button>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            `
                        }}
                    ]
            } );

            $('.daterange').daterangepicker({
                ranges: {
                    "Today": [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    '7 last days': [moment().subtract(6, 'days'), moment()],
                    '30 last days': [moment().subtract(29, 'days'), moment()],
                    'This month': [moment().startOf('month'), moment().endOf('month')],
                    'Last month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                autoUpdateInput: false,
                opens: "left",
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                }
            });

            //get column index for date range
            var visiblecolumnIndex;
            var dataColumnIndex; //current data column to work with

            $("#LoanRequestTable_wrapper tfoot").on("mousedown", "th", function(event) {
                visiblecolumnIndex = $(this).parent().children().index($(this));
                dataColumnIndex = $("tr:first-child").children(':eq(' + visiblecolumnIndex + ')').attr('data-column-index');
                console.log('col: ' + visiblecolumnIndex);
            });

            var startDate;
            var endDate;

            var DateFilterFunction = (function(settings, data, iDataIndex) {

                var filterstart = startDate;
                var filterend = endDate;
                var iStartDateCol = visiblecolumnIndex;
                var iEndDateCol = visiblecolumnIndex;

                var tabledatestart = data[iStartDateCol] !== "" ? moment(data[iStartDateCol].split('T')[0], "YYYY-MM-DD") : data[iStartDateCol];
                var tabledateend = data[iEndDateCol] !== "" ? moment(data[iEndDateCol].split('T')[0], "YYYY-MM-DD") : data[iEndDateCol];

                if (filterstart === "" && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && filterend === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isAfter(tabledatestart)) && filterstart === "") {
                    return true;
                } else if ((moment(filterstart, "YYYY-MM-DD").isSame(tabledatestart) || moment(filterstart, "YYYY-MM-DD").isBefore(tabledatestart)) && (moment(filterend, "YYYY-MM-DD").isSame(tabledateend) || moment(filterend, "YYYY-MM-DD").isAfter(tabledateend))) {
                    return true;
                }

                return false;


            });

            $(".daterange", this).on('apply.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });

            $(".daterange", this).on('cancel.daterangepicker', function(ev, picker) {
                ev.preventDefault();
                $(this).val('');
                startDate = '';
                endDate = '';
                $.fn.dataTableExt.afnFiltering.push(DateFilterFunction);

                table.draw();
            });
    
            

            // Apply the search
            $.each($('.input-filter', table.table().footer()), function () {
                var column = table.column($(this).index());
                
                $('input', this).on('keyup change', function () {
                    if (column.search() !== this.value) {
                        column
                            .search(this.value)
                            .draw();
                    }
                });
            });   

            
            $('#MinFrom, #MaxFrom').keyup( function() {
                table.draw();
            } );

            $('#MinTo, #MaxTo').keyup( function() {
                table.draw();
            } );

            $('#MinAsset, #MaxAsset').keyup( function() {
                table.draw();
            } );
        }
    });
});