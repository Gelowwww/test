let regionDropdown = document.querySelector('#RegionName');

$(document).ready(function() {
    changeRegionToHo();
    
    if(regionDropdown.value.toLowerCase() === "ho") {
        $('#Areas').prop('disabled', true);
        $('#Areas').trigger('chosen:updated');
    } else {
        $('#Areas').prop('disabled', false);
        $('#Areas').trigger('chosen:updated');
    }
    filterDropdownList();
})

function getAreas() {
    var ajax; 
    ajax = $.ajax({
        url: '/data/getarearegion',
        type: 'GET',
        dataType: 'JSON',
        async: false
    });

    return ajax;
}

function getAreaSelectedLength() {
    return Object.keys($('#Areas :selected')).length - 2;
}

function clearAreaMultiSelectList() {
    let areaCloseButtons = document.querySelector('#Areas_chosen').querySelectorAll('.search-choice-close');
    for(let button of areaCloseButtons) {
        button.click();
    }
}

function showAreas() {
    if(regionDropdown.value.toLowerCase() === "ho") {
        $('#Areas').empty();
        hoSelected();
    } else {
        $('#Areas').empty();
        regionSelected();
    }
}

function hoSelected() {
    // $('#Areas option').remove();
    let list = getAreas().responseJSON;

    let areas = getAreas().responseJSON.map(x => x['AreaId']);
    let areasToRetain = list.map(x => x['AreaId']);
    let filter = areas.filter((x) => !areasToRetain.includes(x));
    
    filter.map(x => $(`#Areas option[value='${x}']`).remove());

    list.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.AreaName;
        opt.value = element.AreaId;
        console.log(opt);
        $('#Areas').append(opt);
    });
    $('#Areas option').prop('selected', true);
    $('#Areas').prop('disabled', true);
    $('#Areas').trigger('chosen:updated');
}

function filterDropdownList() {
    if(regionDropdown.value.toLowerCase() !== "ho") {
        let list = getAreas().responseJSON.filter(x => x.RegionName.toLowerCase() === regionDropdown.value.toLowerCase());

        let areas = getAreas().responseJSON.map(x => x['AreaId']);
        let areasToRetain = list.map(x => x['AreaId']);
        let filter = areas.filter((x) => !areasToRetain.includes(x));
        
        filter.map(x => $(`#Areas option[value='${x}']`).remove());

        $('#Areas').trigger('chosen:updated');
    }
}

function regionSelected() {
    $('#Areas').prop('disabled', false);
    let list = getAreas().responseJSON.filter(x => x.RegionName.toLowerCase() === regionDropdown.value.toLowerCase());

    let areas = getAreas().responseJSON.map(x => x['AreaId']);
    let areasToRetain = list.map(x => x['AreaId']);
    let filter = areas.filter((x) => !areasToRetain.includes(x));
    
    filter.map(x => $(`#Areas option[value='${x}']`).remove());

    list.forEach(element => {
        var opt = document.createElement('option');
        opt.text = element.AreaName;
        opt.value = element.AreaId;
        console.log(opt);
        $('#Areas').append(opt);
    });
    $('#Areas').trigger('chosen:updated');
}

function submitClicked() {
    $('#Areas').prop('disabled', false);
    $('#Areas').trigger('chosen:updated');
}

function changeRegionToHo() {
    let response = getAreas();

    response.done(x => {
        if(x.length === getAreaSelectedLength()) {
            regionDropdown.selectedIndex = regionDropdown.length - 1;
        }
    });

    
}