
const username = document.getElementById('UserName');
const fullname = document.getElementById('FullName');

function getLdapUsername() {
    fullname.value = '';
    $.ajax({
        url: '/auth/validateldapusername/',
        type: 'GET',
        dataType: 'JSON',
        data: {ldapname: username.value},
        success: (data) => {
            if(data.FullName != null && username.value.length > 0) {
                alert('Success');
                fullname.value = data.FullName;
                username.readOnly = true;
            } else {
                alert('This username is not found within the organizations LDAP.');
            }
        },
        error: (err) => {
            alert('An error has occurred, kindly try again.');
        }
    });
};

function clearFields() {
    username.value = '';
    fullname.value = '';
    username.readOnly = false;
};
