let getAreas = $.ajax({
    url: '/data/getareasinregion/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
});

let authDropDown = document.getElementById('ApprovingAuthorityName');
let getAuths = $.ajax({
    url: '/data/getauthoritiesfromgroup/',
    type: 'GET',
    dataType: 'JSON',
    async: false,
    success: (data) => {
        return data;
    }
  });

$(document).ready(function () {
    showAreaList();
    areaOnChange();
});

let regionDropDown = document.getElementById('RegionName');
let areaDropDown = document.getElementById('AreaId');
let arealist;

areaDropDown.addEventListener('change', areaOnChange);

function areaOnChange() {
    authDropDown.options.length = 0;
    let authList = getAuths.responseJSON.filter(x => x.AreaName.toLowerCase() == areaDropDown.options[areaDropDown.selectedIndex].text.toLowerCase());


    var noDupAuth = [];
    
    authList.forEach((x) => {
        x['ApprovingAuthorities'].forEach((y) => {
        noDupAuth.push(y);
        });
    });

    var items = [...new Set(noDupAuth)];

    items.forEach((x) => {
        var opt = document.createElement('option');
        opt.text = x;
        opt.value = x;
        authDropDown.add(opt);
    })
  }

regionDropDown.addEventListener('change', showAreaList);

function showAreaList() {
    areaDropDown.options.length = 0;
    let arealist = getAreas.responseJSON.filter(x => x.RegionName.toLowerCase() == regionDropDown.options[regionDropDown.selectedIndex].text.toLowerCase());


    arealist.forEach(x => {
        var opt = document.createElement('option');
        opt.text = x.AreaName;
        opt.value = x.AreaId;
        areaDropDown.add(opt);
    });

    areaOnChange();
}